import numpy as np
from numpy.linalg import cholesky
import matplotlib.pyplot as plt

lamada = 0.01
maxtimes = 5
def productData():
    sampleNo = 50
    mu = np.array([[0, 8]])
    mu1 = np.array([[0, 6.5]])
    Sigma = np.array([[1, 0.5], [1.5, 3]])
    R = cholesky(Sigma)
    s = mu + np.dot(np.random.randn(sampleNo, 2), R)
    s1 = mu1 + np.dot(np.random.randn(sampleNo, 2), R)
    x = []
    y = []
    for i in range(len(s)):
        a = []
        a.append(1)
        for j in s[i]:
            a.append(j)
        x.append(a)
        y.append(1)
    for i in range(len(s1)):
        a = []
        a.append(1)
        for j in s1[i]:
            a.append(j)
        x.append(a)
        y.append(0)
    return x, y

def sigmoid(x, w):
    return 1.0/(1 + np.exp(-x*w))

def newton(data_x, data_y):
    X = np.mat(data_x)
    Y = np.mat(data_y).transpose()
    X_T = X.transpose()
    m, n = np.shape(X)
    thata = np.mat(np.zeros((n, 1)))
    for k in range(maxtimes):
        h = sigmoid(X, thata)
        error = h - Y
        J_dao = np.multiply(1 / m, X_T * error)
        Hessai = np.multiply(1 / m, X_T * Hessaijuzhen(h) * X)
        thata = thata - np.dot(Hessai.I, J_dao)
    return thata.getA()


def newtonPenaty(data_x, data_y):
    X = np.mat(data_x)
    Y = np.mat(data_y).transpose()
    X_T = X.transpose()
    m, n = np.shape(X)
    thata = np.mat(np.zeros((n, 1)))
    for k in range(maxtimes):
        h = sigmoid(X, thata)
        error = h - Y
        J_dao = np.multiply(1 / m, X_T * error)
        Hessai = np.multiply(1 / m, X_T * Hessaijuzhen(h) * X)
        thata = thata - np.dot(Hessai.I, J_dao) + lamada*thata
    return thata.getA()
def Hessaijuzhen(h):
    return np.diag(np.multiply(h, (1 - h)).T.getA()[0])

def paint(w, w1 ,x, y):
    data_x_arr = np.array(x)
    x1 = []
    y1 = []
    x2 = []
    y2 = []
    n = len(y)
    for i in range(n):
        if int(y[i]) == 0:
            x1.append(data_x_arr[i][1])
            y1.append(data_x_arr[i][2])
        else:
            x2.append(data_x_arr[i][1])
            y2.append(data_x_arr[i][2])
    x = np.arange(-3.0, 3.0, 0.1)
    y = (-w[0] - w[1] * x) / w[2]
    yn = (-w1[0] - w1[1] * x) / w1[2]
    plt.figure("aaaaa")
    plt.title("aaaaaa")
    plt.scatter(x1, y1, s=20, c='red', marker='s', alpha=.5)
    plt.scatter(x2, y2, s=20, c='green', alpha=.5)
    plt.plot(x, y, 'r', label="$NoPenatyt$")
    plt.plot(x, yn, 'b--', label="$Penaty$")
    plt.legend(loc=0)
    plt.show()
    return


if __name__ == '__main__':
    print("迭代次数 ： {}".format(maxtimes))
    data_x, data_y = productData()
    best_w = newton(data_x, data_y)
    best_w1 = newtonPenaty(data_x,data_y)
    paint(best_w, best_w1, data_x, data_y)