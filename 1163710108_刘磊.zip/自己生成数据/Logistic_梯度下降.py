import numpy as np
import matplotlib.pyplot as plt

lamada = 0.001
maxtimes = 800
alpha = 0.1
def productData():
    sampleNo = 50
    mu = np.array([[0, 8]])
    mu1 = np.array([[0, 6.0]])
    R = np.array([[1.0,0],[0,0.9]])
    s = mu + np.dot(np.random.randn(sampleNo, 2), R)
    R1 = np.array([[0.5,0],[0,0.4]])
    s1 = mu1 + np.dot(np.random.randn(sampleNo, 2), R1)
    x = []
    y = []
    for i in range(len(s)):
        a = []
        a.append(1)
        for j in s[i]:
            a.append(j)
        x.append(a)
        y.append(1)
    for i in range(len(s1)):
        a = []
        a.append(1)
        for j in s1[i]:
            a.append(j)
        x.append(a)
        y.append(0)
    return x, y

'''
函数说明:
        Sigmoid函数
'''
def sigmoid(x, w):
    return 1.0/(1 + np.exp(-x*w))

"""
函数说明:梯度上升算法  无惩罚项
参数1 : 数据集 
参数2： W 梯度下降法所求的 参数列向量
返回值： 最佳的参数列向量
"""
def descentNoPenalty(X, W):
    x_data = np.mat(X)
    y_data = np.mat(W).T
    m, n = np.shape(x_data)
    w_best = np.zeros((n, 1))
    for k in range(maxtimes):
        h = sigmoid(x_data, w_best)
        error = h-y_data
        w_best = w_best - alpha/m * x_data.transpose() * error
    return w_best.getA()


"""
函数说明:梯度上升算法  有惩罚项
参数1 : 数据集 
参数2： W 梯度下降法所求的 参数列向量
返回值： 最佳的参数列向量
"""
def descentPenalty(X, W):
    x_data = np.mat(X)
    y_data = np.mat(W).transpose()
    m, n = np.shape(x_data)
    w_best = np.zeros((n, 1))
    for k in range(maxtimes):
        h = sigmoid(x_data, w_best)
        error = h-y_data
        w_best = w_best - alpha/m * x_data.transpose() * error  + lamada *w_best
    return w_best.getA()
'''
函数说明:
        绘制图画
'''
def paint(w, w1, x, y):
    data_x_arr = np.array(x)
    x1 = []
    y1 = []
    x2 = []
    y2 = []
    n = len(y)
    for i in range(n):
        if int(y[i]) == 0:
            x1.append(data_x_arr[i][1])
            y1.append(data_x_arr[i][2])
        else:
            x2.append(data_x_arr[i][1])
            y2.append(data_x_arr[i][2])
    x = np.arange(-4.0, 4.0, 0.1)
    y = (-w[0] - w[1] * x) / w[2]
    yn = (-w1[0] - w1[1] * x) / w1[2]
    plt.figure("aaaaa")
    plt.title("aaaaaa")
    plt.scatter(x1, y1,)
    plt.scatter(x2, y2,)
    plt.plot(x, y,  'r', label="$NoPenatyt$")
    plt.plot(x, yn, 'b--', label="$Penaty$")
    plt.legend(loc=0)
    plt.show()
    return

if __name__ == '__main__':
    print("迭代的次数 : {}".format(maxtimes))
    data_x, data_y = productData()
    best_w = descentNoPenalty(data_x, data_y)
    best_w1 = descentPenalty(data_x,data_y)
    paint(best_w, best_w1, data_x, data_y)
