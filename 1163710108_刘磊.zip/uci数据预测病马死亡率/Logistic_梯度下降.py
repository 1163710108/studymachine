import numpy as np
lamada = 0.001
maxtimes = 200
alpha = 0.01
#logistic函数
def sigmoid(x, w):
    return 1.0/(1 + np.exp(-x*w))

#没有惩罚项
def descentNoPenalty(X, W):
    x_data = np.mat(X)
    y_data = np.mat(W).T
    m, n = np.shape(x_data)
    w_best = np.ones((n, 1))
    for k in range(maxtimes):
        h = sigmoid(x_data, w_best)
        error = h-y_data
        w_best = w_best - alpha/m * x_data.transpose() * error
    return w_best.getA()

#有惩罚项
def descentPenalty(X, W):
    x_data = np.mat(X)
    y_data = np.mat(W).transpose()
    m, n = np.shape(x_data)
    w_best = np.ones((n, 1))
    for k in range(maxtimes):
        h = sigmoid(x_data, w_best)
        error = h-y_data
        w_best = w_best - alpha/m * x_data.transpose() * error -lamada *w_best
    return w_best.getA()

def productData(file):
    f = open(file)
    dataMat = []
    datalabel = []
    for i in f.readlines():
        line = i.strip().split("\t")
        linea = []
        for j in range(len(line)-1):
            linea.append(float(line[j]))
        dataMat.append(linea)
        datalabel.append(float(line[-1]))
    return dataMat,datalabel


if __name__ == '__main__':
    data_x , data_y = productData('horseColicTraining.txt')
    test_x , test_y = productData('horseColicTest.txt')
    W_withNoPenalty = descentNoPenalty(data_x,data_y)
    W_withPenalty = descentPenalty(data_x, data_y)
    a = sigmoid(np.mat(test_x) , W_withNoPenalty)
    a1 = sigmoid(np.mat(test_x) , W_withPenalty)
    y_1 =  np.array(a).reshape(1,len(a))[0]
    y_2 = np.array(a1).reshape(1,len(a1))[0]
    sure1 = 0
    sure2 = 0
    for i in range(len(y_1)):
        if y_1[i] <= 0.5 and test_y[i] ==0:
            sure1 = sure1 +1
        elif y_1[i] > 0.5 and test_y[i] == 1:
            sure1 = sure1 + 1
        if y_2[i] <= 0.5 and test_y[i]:
            sure2 = sure2 + 1
        elif y_2[i] > 0.5 and test_y[i]:
            sure2 = sure2 + 1
    print("迭代的次数 ： {}".format(maxtimes))
    print("无惩罚项 逻辑回归 梯度下降法的 准确率为 : {}".format(sure1/len(test_y)) )
    print("有惩罚项 逻辑回归 梯度下降法的 准确率为 : {}".format(sure2/len(test_y)) )
