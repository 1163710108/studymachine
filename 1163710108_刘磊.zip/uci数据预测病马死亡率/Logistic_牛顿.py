
import numpy as np

import matplotlib.pyplot as plt

#logistic函数

lamada = 0.01
maxtimes = 500
def sigmoid(x, w):
    return 1.0/(1 + np.exp(-x*w))
# 无惩罚项
def newton(data_x, data_y):
    X = np.mat(data_x)
    Y = np.mat(data_y).transpose()
    X_T = X.transpose()
    m, n = np.shape(X)
    thata = np.mat(np.zeros((n, 1)))
    for k in range(maxtimes):
        h = sigmoid(X, thata)
        error = h - Y
        J_dao = np.multiply(1 / m, X_T * error)
        Hessai = np.multiply(1 / m, X_T * Hessaijuzhen(h) * X)
        thata = thata - np.dot(Hessai.I, J_dao)
    return thata.getA()

# 有惩罚项
def newtonPenaty(data_x, data_y):
    X = np.mat(data_x)
    Y = np.mat(data_y).transpose()
    X_T = X.transpose()
    m, n = np.shape(X)
    thata = np.mat(np.zeros((n, 1)))
    for k in range(maxtimes):
        h = sigmoid(X, thata)
        error = h - Y
        J_dao = np.multiply(1 / m, X_T * error)
        Hessai = np.multiply(1 / m, X_T * Hessaijuzhen(h) * X)
        thata = thata - (np.dot(Hessai.I, J_dao) + lamada*thata)
    return thata.getA()

def Hessaijuzhen(h):
    return np.diag(np.multiply(h, (1 - h)).T.getA()[0])

def productData(file):
    f = open(file)
    dataMat = []
    datalabel = []
    for i in f.readlines():
        line = i.strip().split("\t")
        linea = []
        for j in range(len(line)-1):
            linea.append(float(line[j]))
        dataMat.append(linea)
        datalabel.append(float(line[-1]))
    return dataMat,datalabel

if __name__ == '__main__':
    data_x , data_y = productData('horseColicTraining.txt')
    test_x , test_y = productData('horseColicTest.txt')
    W_withNoPenalty = newton(data_x,data_y)
    W_withPenalty = newtonPenaty(data_x, data_y)
    a = sigmoid(np.mat(test_x), W_withNoPenalty)
    a1 = sigmoid(np.mat(test_x), W_withPenalty)
    y_1 = np.array(a).reshape(1, len(a))[0]
    y_2 = np.array(a1).reshape(1, len(a1))[0]
    sure1 = 0
    sure2 = 0
    for i in range(len(y_1)):
        if y_1[i] <= 0.5 and test_y[i] == 0:
            sure1 = sure1 + 1
        elif y_1[i] > 0.5 and test_y[i] == 1:
            sure1 = sure1 + 1
        if y_2[i] <= 0.5 and test_y[i]:
            sure2 = sure2 + 1
        elif y_2[i] > 0.5 and test_y[i]:
            sure2 = sure2 + 1
    print("迭代次数 : {}".format(maxtimes))
    print("无惩罚项 逻辑回归 牛顿法 准确率为 : {}".format(sure1 / len(test_y)))
    print("有惩罚项 逻辑回归 牛顿法 准确率为 : {}".format(sure2 / len(test_y)))
